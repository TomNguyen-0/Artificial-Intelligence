
"""
ai - search & strategy module

implement a concrete Strategy class and AlphaBetaSearch
"""


class Strategy:
    pass



class AlphaBetaSearch:
    pass
